package com.example.transportation4oku

class AdminBooking {
    var name: String ?= null
    var from: String ?= null
    var to: String ?= null
    var status: String ?=null
    var date: String ?=null

    constructor()
}

