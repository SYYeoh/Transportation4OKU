package com.example.transportation4oku

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AdminManageUser : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_manage_user)
    }
}