package com.example.transportation4oku

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OKUMain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_okumain)
    }
}